import RPi.GPIO as GPIO
import time
import cv2
import tf_livestream as tflive
import time

GPIO.setmode(GPIO.BCM)
TRIG = 21
ECHO = 20

# Change this to whatever IP you're using
ip = '0.0.0.0'
port = 3000

# Change this to the absolute path you want to write the image to.
#
# e.g., if you want to save your image in your downloads folder,
# you would use '/home/pi/Downloads', where 'pi' is your username.
img_path = './images/00000.jpg'

while True:
    print("Distance Check")
    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)
    GPIO.output(TRIG, False)

    print("Set up completed")
    time.sleep(0.2)
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    print("Distance:", distance, "cm")
    print()
    time.sleep(2)

    if 0 < distance < 10:
        vc = cv2.VideoCapture(0)
        ret, frame = vc.read()
        vc.release()

        cv2.imwrite(img_path, frame)

        tflive.start(ip=ip, port=port)