from flask import Response
from flask import Flask
import threading
import time
import cv2
import argparse
from tflite_predict import predict
import os
import signal
from gpiozero import Servo
import RPi.GPIO as GPIO

lock = threading.Lock()
app = Flask(__name__)
img_path = './images/00000.jpg'
score_threshold = 0.4
error_margin = 0

TRIG1 = 5
ECHO1 = 6

global sig
sig = getattr(signal, 'SIGKILL', signal.SIGTERM)

def get_video():
    global vc, outputFrame, lock

    while True:
        ret, frame = vc.read()

        with lock:
            outputFrame = frame.copy()


def get_picture():
    global outputFrame, lock, sig, forever

    while True:
        time.sleep(10.0)

        with lock:
            cv2.imwrite(img_path, outputFrame)
            #score = predict(img_path)

            #if score > score_threshold + error_margin and forever == None:
            #    os.kill(os.getpid(), sig)


def generate():
    global outputFrame, lock

    while True:
        with lock:
            if outputFrame is None:
                continue

            (flag, encodedImage) = cv2.imencode(".jpg", outputFrame)

            if not flag:
                continue

        yield(b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + 
            bytearray(encodedImage) + b'\r\n')


@app.route("/video_feed")
def video_feed():
    return Response(generate(),
        mimetype = "multipart/x-mixed-replace; boundary=frame")

def ultra():
    GPIO.setwarnings(False)
    print()
    print("Distance Check")
    GPIO.setup(TRIG1, GPIO.OUT)
    GPIO.setup(ECHO1, GPIO.IN)
    GPIO.output(TRIG1, False)
        
    print("Check food basket emptiness")
    time.sleep(0.2)
    GPIO.output(TRIG1, True)
    time.sleep(0.00001)
    GPIO.output(TRIG1, False)
        
    while GPIO.input(ECHO1) == 0:
        pulse_start = time.time()
    while GPIO.input(ECHO1) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance1 = pulse_duration * 17150
    distance1 = round(distance1, 2)
        
    print("Distance:", distance1, "cm")
    print()
    time.sleep(2)
        
    if 10 < distance1 < 20:
        servo = Servo(17)
        servo.max()
        time.sleep(1)
        servo.min()

def start(ip, port, endless=None):
    global vc
    
    vc = cv2.VideoCapture(0)
    time.sleep(2.0)

    score = predict(img_path)
    if score < score_threshold:
        global forever
        forever = endless
        
        ultra()

        t = threading.Thread(target=get_video)
        t.daemon = True
        t.start()

        t1 = threading.Thread(target=get_picture)
        t1.daemon = True
        t1.start()

        app.run(host=ip, port=port, debug=False,
                threaded=True, use_reloader=False) 

    else:
        print('Img is not a bird')
    
    vc.release()

if __name__ == '__main__':
    ap = argparse.ArgumentParser()

    ap.add_argument("-i", "--ip", type=str, required=True,
        help="ip address of the device")
    ap.add_argument("-o", "--port", type=int, required=True,
        help="ephemeral port number of the server (1024 to 65535)")
    ap.add_argument('-f',
                    '--forever',
                    type=bool,
                    nargs='?',
                    const=True,
                    required=False,
                    help='Runs the program indefinitely')

    args = vars(ap.parse_args())

    start(ip=args["ip"], port=args["port"], endless=args["forever"])
