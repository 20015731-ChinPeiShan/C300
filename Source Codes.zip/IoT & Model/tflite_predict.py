import tflite_runtime.interpreter as tflite
import cv2
import numpy as np


def predict(img_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (400, 400))
    img = np.float32(img) / 255

    interpreter = tflite.Interpreter(model_path='model.tflite')
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    input_data = np.array(np.expand_dims(img, 0))

    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    output_data = interpreter.get_tensor(output_details[0]['index'])
    score = np.squeeze(output_data)
    
    if score < 0.5:
        print(f'Not Bird : {score}')
    else:
        print(f'Bird : {score}')
    
    return score